/**
 */
package automatedresttesting;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Literal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see automatedresttesting.AutomatedresttestingPackage#getLiteral()
 * @model abstract="true"
 * @generated
 */
public interface Literal extends EObject {
} // Literal
