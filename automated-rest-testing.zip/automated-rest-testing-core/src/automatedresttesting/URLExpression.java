/**
 */
package automatedresttesting;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>URL Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see automatedresttesting.AutomatedresttestingPackage#getURLExpression()
 * @model
 * @generated
 */
public interface URLExpression extends Element {
} // URLExpression
